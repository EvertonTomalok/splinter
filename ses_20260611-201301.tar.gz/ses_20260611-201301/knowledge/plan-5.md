# Plan

No `US-001` spec doc nor canonical codex ids in repo. The "confirmed in US-001" reference is unresolvable from the tree — codex ids must be supplied. Plan flags that as the one open input.

Scope is narrow: AC touches only `roster.py` + `ladder.yaml` + a roster unit test. The large provider/CLI/README context is localization noise — out of scope for US-005. Plan stays on AC.

## Implementation Plan — US-005: codex structs in ladder.yaml + roster.py

**Open input (blocking ladder.yaml):** canonical codex ids "confirmed in US-001" not in repo. Need exact ids + count of tiers. Assumed convention below: `codex/` prefix (mirrors `opencode/`), e.g. `codex/gpt-5.1-codex`. Confirm before writing.

1. **`provider_for()` — `splinter/models/roster.py:11`** — add codex branch before the claude fallback:
   ```python
   if model_id.startswith("codex/"):
       return "codex"
   ```
   Keeps routing rule absolute (prefix → provider), same shape as opencode.

2. **codex model structs — `splinter/models/roster.py`** — add module-level canonical id constants (the "codex model structs" of the AC), typed, near top after imports:
   ```python
   CODEX_MODELS: dict[str, str] = {
       "gpt5_codex": "codex/gpt-5.1-codex",
       # ...remaining canonical ids from US-001
   }
   ```
   Use a frozen `@dataclass` only if US-001 ids carry per-model metadata (variant/context); if they're bare ids, a `dict[str,str]` (or `tuple`) matches existing `models:` anchor style and stays mypy-strict clean.

3. **`codex_model_ids()` helper — `splinter/models/roster.py:86`** — add symmetric accessor next to `opencode_model_ids()`:
   ```python
   def codex_model_ids(self) -> list[str]:
       return [m for t in self.tiers if t.provider == "codex" for m in t.models]
   ```
   No change needed to `Tier`/`Ladder` dataclasses — `provider: str` already generic; `load_ladder` reads `provider` via `td.get("provider", ...)` so codex tiers parse with zero loader change.

4. **`splinter/models/ladder.yaml`** — (a) add codex anchors to the `models:` registry block (L6-14):
   ```yaml
   codex_high: &codex_high codex/gpt-5.1-codex
   ```
   (b) add codex tier(s) to `tiers:` with explicit `provider: codex`, canonical ids via anchor, and a `variant`:
   ```yaml
   - name: codex
     level: 6
     provider: codex
     models:
       - *codex_high
     variant: high
   ```
   Pick level above current max (5 = last-resort) unless US-001 dictates placement. Do not reorder existing tiers — AC: "do not force any previous test to pass."

5. **Unit test — `tests/test_core.py`** — add `test_roster_loads_codex_tiers`:
   - `load_ladder()`, assert a tier with `provider == "codex"` exists.
   - assert its models are non-empty and each `provider_for(m) == "codex"`.
   - assert `ladder.codex_model_ids()` returns those ids.
   - assert `provider_for("codex/...") == "codex"` and existing `opencode`/`claude` routing unchanged (regression guard).

6. **Gate — typecheck/lint:**
   ```
   mypy --strict splinter/models/roster.py
   ruff check splinter/models/roster.py tests/test_core.py
   ```
   `from __future__ import annotations` already present. No comments added (convention). Line length ≤100.

7. **Run test suite** — `pytest tests/test_core.py -k codex` plus full `pytest` to confirm no prior test regressed.

**Out of scope (other US):** `providers/codex.py`, `registry.py` registration, `dispatch.py` routing, `configure.py` TUI, `cli.py verify`, README. US-005 is structs + ladder only; routing string `"codex"` will dangle until the provider US registers it — acceptable per AC.

Want me to resolve the codex ids decision (step open-input) via the US-001 source, or proceed with the `codex/` placeholder convention?
