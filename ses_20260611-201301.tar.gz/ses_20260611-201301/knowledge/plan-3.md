# Plan

`codex.py` not exist yet. CodexProvider class missing. US-003 scoped to registry only — depends on prior task (codex.py + CodexProvider with `name = "codex"`). Plan below assumes that exists; step 0 guards it.

## Implementation Plan — US-003: register CodexProvider

1. **Precondition check** — `splinter/providers/codex.py` must define `CodexProvider(ModelProvider)` with class attr `name = "codex"` and implemented `run()`. Currently absent. If still missing at impl time → blocked on the codex.py task; do not stub here (out of scope). Verify: `grep -n 'class CodexProvider\|name = "codex"' splinter/providers/codex.py`.

2. **Edit `splinter/providers/registry.py`** — add import after line 11, alphabetical/isort order (Ruff I):
   ```python
   from splinter.providers.codex import CodexProvider
   ```
   (Ruff isort sorts `claude_cli` < `codex` < `opencode` — `codex` import goes between them.)

3. **Edit `_PROVIDERS` tuple (line 13)** — add `CodexProvider()`:
   ```python
   _PROVIDERS: dict[str, ModelProvider] = {
       p.name: p for p in (ClaudeProvider(), OpencodeProvider(), CodexProvider())
   }
   ```
   `get_provider("codex")` resolves via `name` key automatically. `available_providers()` picks it up free. No change to `get_provider`/`available_providers` bodies.

4. **Add unit test** in `tests/test_core.py` near line 643 (existing `get_provider("claude")` test):
   ```python
   def test_get_provider_returns_codex() -> None:
       from splinter.providers.codex import CodexProvider

       provider = get_provider("codex")
       assert isinstance(provider, CodexProvider)
       assert provider.name == "codex"
   ```
   Type hints required (`-> None`), mypy --strict clean.

5. **Gate: typecheck + lint** —
   ```
   mypy --strict splinter/providers/registry.py
   ruff check splinter/providers/registry.py tests/test_core.py
   ```

6. **Run tests** — `pytest tests/test_core.py -k provider -q`. New test passes; existing `test_core` provider tests unchanged (no regressions).

**Out of scope** (other US): codex.py impl, dispatch.py model routing, roster/ladder.yaml, README, AGENTS.md, cli.py verify. Touch only `registry.py` + `tests/test_core.py`.
