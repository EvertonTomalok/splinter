# Plan

Read `roster.py`. Scope narrow — only `provider_for` + codex resolution path. Plan:

## Implementation Plan — US-002

1. **`splinter/models/roster.py` → `provider_for(model_id)`** (L11-15): add codex prefix branch as safety net, before the claude fallback:
   ```python
   def provider_for(model_id: str) -> str:
       """Infer the provider from a model id."""
       if model_id.startswith("codex/"):
           return "codex"
       if model_id.startswith("opencode-go/") or model_id.startswith("opencode/"):
           return "opencode"
       return "claude"
   ```
   Prefix inference = safety net. No `codex` in default fallback chain — only explicit `codex/` prefix triggers it.

2. **`load_ladder` (L114-128) — no code change, verify behavior**: `provider.get("provider", "opencode")` default stays. Codex tiers in `ladder.yaml` MUST carry explicit `provider: codex` since default is `opencode` and `provider_for` only infers codex from prefix — never from default. This satisfies AC "no opencode default fallback for codex" (a codex tier without explicit label silently becomes opencode by design, forcing config authors to be explicit). Confirm no special-casing added that would auto-infer codex from default.

3. **`tests/test_core.py` — add `test_provider_for_codex_resolution`** (one test, two asserts; AC unit test):
   - **Prefix inference**: `assert provider_for("codex/gpt-5") == "codex"`.
   - **Explicit label**: build ladder via `load_ladder({"tiers": [{"name": "x", "level": 0, "models": ["gpt-5"], "provider": "codex"}], ...})` (minimal raw dict), assert `ladder.tier_by_level(0).provider == "codex"` — explicit label survives load, not overridden by `opencode` default.
   - Also guard regression: `assert provider_for("opencode/foo") == "opencode"` and `assert provider_for("sonnet") == "claude"` still hold (don't break existing routing).

4. **Gate — typecheck/lint** (AC gate):
   - `mypy --strict splinter/models/roster.py` — clean (return type already `str`, no new untyped defs).
   - `ruff check splinter/models/roster.py tests/test_core.py` — E/F/W/I clean, line length ≤100.

5. **Run test suite**: `pytest tests/test_core.py -k codex` — new test passes. Run full `pytest` to confirm no prior test forced/broken (AC: "Do not force any previous test to pass").

**Out of scope** (other codex-epic tasks, not US-002): new `codex.py` provider, registry/dispatch wiring, ladder.yaml codex models, README/AGENTS docs, CLI verify. This story is `provider_for` resolution only.

Note: `dispatch.run_text` (L19-35) still calls `provider_for(model)` and branches only `opencode`/else-claude — a `"codex"` return currently falls to the claude branch. Resolving that routing is dispatch's job (separate task). Flag it so the mislabel risk isn't assumed fixed here.
