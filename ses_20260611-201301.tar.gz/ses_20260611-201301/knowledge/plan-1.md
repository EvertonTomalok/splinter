# Plan

Have full picture. No codex refs exist yet. Plan below.

## Confirmed against installed codex CLI (v0.139.0)

- **Invocation**: `codex exec` (non-interactive). Flags: `-m <model>`, `--json` (JSONL events on stdout), `-o <FILE>` (final message to file), `-s read-only|workspace-write|danger-full-access`, `--dangerously-bypass-approvals-and-sandbox`, `--skip-git-repo-check`, `-c key=value` (config overrides, TOML). Reasoning effort is **not** a flag → set via `-c model_reasoning_effort=<v>`.
- **JSONL event shape** (real capture):
  - `{"type":"thread.started","thread_id":"<uuid>"}` → session id
  - `{"type":"item.completed","item":{"type":"agent_message","text":"..."}}` → final text
  - `{"type":"turn.completed","usage":{"input_tokens":..,"cached_input_tokens":..,"output_tokens":..,"reasoning_output_tokens":..}}` → tokens. **No cost field** → need pricing table.
- **Session resume**: `codex exec resume <session_id> <prompt>` (session id = `thread_id`).
- **Confirmed model id**: `gpt-5-codex` (ran OK). Auth = API key, already logged in.
- I/O does **not** match claude/opencode — distinct event names (`thread.started`/`item.completed`/`turn.completed`), no cost, reasoning effort via `-c`.

---

## Implementation Plan

1. **`splinter/providers/codex.py`** — new file, mirror `claude_cli.py` structure:
   - `from __future__ import annotations`; imports `run_subprocess` (`splinter.procreg`), `ModelProvider`, `ProviderResponse`, `detect_provider_gap` (`splinter.providers.base`); `_stream_log = logging.getLogger("splinter.live")`.
   - `@dataclass(frozen=True) CodexResult(text: str, tokens: dict[str, int], cost: float, raw: dict[str, Any], session_id: str | None)`.
   - `_PRICING: dict[str, tuple[float, float]]` keyed by codex model ids (input/output $/1M) + `_calc_cost(model, usage)` (parallel to `claude_cli._calc_cost`). Confirm rates for US-005.
   - `_EFFORTS = {"minimal","low","medium","high"}` + alias map (`auto`→None) → `_normalize_effort`; confirm accepted set against CLI.
   - `_strip_prefix(model)` → drop `codex/` before passing to `-m`.
   - `_parse_jsonl(stdout)` → iterate lines: capture `thread_id` from `thread.started`; concat `item.completed` `agent_message` `text`; capture `usage` from `turn.completed`. Return dict.
   - `_stream_codex_event(line)` → live `🔧`/`💬` log for `item.*`/command events (parallel to `_stream_claude_event`).
   - `run(prompt, model, *, effort=None, output_format="json", resume=None, timeout=None) -> CodexResult`: build `["codex","exec","--json","--skip-git-repo-check","--dangerously-bypass-approvals-and-sandbox","-m",model,...]`; append `-c model_reasoning_effort=<effort>` when set; for resume use `["codex","exec","resume",resume,...]`; terminate args before prompt (verify `--` accepted by `codex exec`; else pass prompt positionally). Default timeout from `configure.configured_timeout()`. Raise `RuntimeError(f"codex exited {rc}: {stderr}")` on nonzero. Parse text/tokens/session_id; compute cost.
   - `ping(model="gpt-5-codex", timeout=30) -> bool` (parallel to claude).
   - `class CodexProvider(ModelProvider)`: `name = "codex"`; `run(self, prompt, model, *, variant=None, session=None, timeout=None) -> ProviderResponse` — call module `run(..., effort=variant, resume=session)`, wrap `detect_provider_gap` on exception **and** on result text (codex may exit 0 on API error — verify), return `ProviderResponse(text, tokens={"input":..,"output":..}, cost, raw, session_id)`.

2. **`splinter/models/roster.py:provider_for`** — add codex branch before claude fallback:
   ```python
   if model_id.startswith("codex/"):
       return "codex"
   ```
   Convention: codex model ids carry `codex/` prefix (e.g. `codex/gpt-5-codex`); provider strips it for `-m`.

3. **`splinter/providers/registry.py`** — import `CodexProvider`, add to `_PROVIDERS` tuple: `(ClaudeProvider(), OpencodeProvider(), CodexProvider())`.

4. **`splinter/providers/dispatch.py`** — extend `run_text`, `run_text_session`, `run_provider_session` from 2-way to 3-way: add `elif provider_for(model) == "codex":` branch calling `codex.run(prompt, model, effort=variant, output_format=..., resume=session, timeout=...)`, logging tokens/cost via `_log`, returning text / (text, sid) / (ProviderResponse, sid) matching each function's shape. Import `codex` alongside `claude_cli, opencode`.

5. **`splinter/models/ladder.yaml`** — add codex model anchor(s) under `models:` (e.g. `codex_gpt5: &codex_gpt5 codex/gpt-5-codex`). Do not rewire existing tiers (runs sequential; no tier needs codex unless asked) — only register so roster/configure can select. Record confirmed canonical ids here for US-005.

6. **`splinter/setup.py`** — add `_check_codex()`: `shutil.which("codex")` + `codex.ping()`; register in `run_setup()` results list. Import `codex`.

7. **`splinter/configure.py`** (`all_selectable_models`, ~L340) — add codex model ids to the selectable set (from `load_ladder().all_model_ids()` already covers ladder-registered codex ids; verify codex ids surface; no live `list_models` call for codex since CLI has no list command).

8. **Docs** — `README.md` (L91 install, L128-139 auth/setup, L262-289 models roster) add codex CLI install + `codex login` + codex models. `AGENTS.md` (L62-71) note codex as supported provider alongside claude/opencode.

9. **Tests** — new `tests/test_codex_provider.py` (discover/mirror opencode+claude test patterns; mock `run_subprocess` to return a fake `CompletedProcess` with the captured JSONL above):
   - `agent_message` text extraction across multi-line JSONL.
   - `usage` → tokens mapping; `_calc_cost` from pricing table.
   - `thread_id` → `session_id`; resume passes `exec resume <id>`.
   - `variant` → `-c model_reasoning_effort=` in argv; `codex/` prefix stripped from `-m`.
   - nonzero exit → `RuntimeError`; gap text → `ProviderGapError` (reuse `detect_provider_gap`).
   - `provider_for("codex/gpt-5-codex") == "codex"`; `get_provider("codex")` returns `CodexProvider`; dispatch routes codex model to `codex.run`.
   - Do not modify/force existing tests.

10. **Gate** — `mypy --strict` + `ruff` (E,F,W,I, line 100, type hints, no comments) pass; run `pytest`.

**Open item to confirm during impl** (cheap CLI checks, not assumptions): exact `model_reasoning_effort` accepted values; whether `codex exec` accepts `--` arg terminator; whether codex exits 0 on API error (drives text-side gap check); full canonical model id list for US-005.
