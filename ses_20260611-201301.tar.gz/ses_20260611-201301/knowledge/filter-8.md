### README.md — File to update with codex setup + models documentation
rtk: rtk read README.md
Primary artifact where codex setup and model configuration must be documented; currently truncated after Requirements section.
```
# 🐀 Splinter

**One model plans. Cheaper models do the work. A judge decides when to level up.**

...

## Requirements

Splinter is the conductor, not the models. You bring the two CLIs it drives:

- **[uv](https://github.com/astral-sh/uv)** the Python project manager Splinter
  is built on
- **Python 3.11+** (uv can install it for you)
- **[Claude Code](https://docs.claude.com/en/docs/claude-code/overview)** the
  `claude` CLI, authenticated, with access to `sonnet` and `opus-4.8`
- **[opencode](https://opencode.ai)** the `opencode` CLI, authenticated on the
  `opencode-go` provider _(not needed if you use `--use-cc-only`, see below)_
- **
```

### splinter/cli.py:L23-28 — setup command
rtk: rtk read splinter/cli.py | sed -n '23,28p'
Defines the setup command that verifies environment and providers; should be documented in README.
```python
@app.command()
def setup() -> None:
    """Verify environment and providers."""
    from splinter.setup import run_setup

    raise typer.Exit(run_setup())
```

### splinter/cli.py:L90-120 — run command with use_cc_only flag
rtk: rtk read splinter/cli.py | sed -n '90,120p'
Shows --use-cc-only flag for Claude-only provider mode; relevant for documenting provider options.
```python
    use_cc_only: Annotated[
        bool,
        typer.Option(
            "--use-cc-only",
            help="Swap to Claude-only runners (haiku/sonnet/opus) before running",
        ),
    ] = False,
```

### splinter/providers/registry.py:L8-19 — provider registry and lookup
rtk: rtk read splinter/providers/registry.py | sed -n '8,19p'
Shows available providers (Claude, Opencode) and how they're registered; documents the provider strategy pattern.
```python
_PROVIDERS: dict[str, ModelProvider] = {p.name: p for p in (ClaudeProvider(), OpencodeProvider())}


def get_provider(name: str) -> ModelProvider:
    """Return the provider strategy registered under ``name``."""
    try:
        return _PROVIDERS[name]
    except KeyError:
        raise ValueError(
            f"unknown provider '{name}'. Available: {', '.join(sorted(_PROVIDERS))}"
        ) from None
```

### splinter/providers/dispatch.py:L1-6 — model-to-provider routing logic
rtk: rtk read splinter/providers/dispatch.py | sed -n '1,6p'
Explains how models are routed to backends by model ID prefix; essential for documenting model naming convention.
```python
"""Route a single model call to the backend that owns the model id.

The rule is simple and absolute: ``opencode-go/*`` ids go to the ``opencode`` CLI,
claude aliases (``opus``/``sonnet``/``haiku``) go to ``claude -p``. Sending an
opencode model to the claude CLI 404s (and vice versa), so every ad-hoc model
call (localize, plan, eval) funnels through here instead of hardcoding a provider.
"""
```

### splinter/models/roster.py:L29-32 — provider inference from model ID
rtk: rtk read splinter/models/roster.py | sed -n '29,32p'
Shows how provider is inferred from model ID prefix; clarifies model naming convention.
```python
def provider_for(model_id: str) -> str:
    """Infer the provider from a model id."""
    if model_id.startswith("opencode-go/") or model_id.startswith("opencode/"):
        return "opencode"
```

### splinter/models/roster.py:L35-63 — Tier and Ladder data structures
rtk: rtk read splinter/models/roster.py | sed -n '35,63p'
Defines how models are organized in tiers and the Ladder structure; critical for documenting model hierarchy.
```python
@dataclass
class Tier:
    name: str
    level: int
    models: list[str]
    provider: str = "opencode"
    variants: dict[str, str | None] = field(default_factory=dict)


@dataclass
class EffortMapping:
    start_tier: int
    variant: str


@dataclass
class Ladder:
    tiers: list[Tier]
    effort_map: dict[str, EffortMapping]
    eval_model: str
    eval_effort: str
    planner_model: str
    planner_effort: str
    localizer_recall_model: str
    localizer_recall_large_model: str
    localizer_precision_model: str
```

### splinter/models/roster.py:L117-121 — load_ladder function
rtk: rtk read splinter/models/roster.py | sed -n '117,121p'
Shows ladder.yaml is the config source for all model tiers; indicates documentation should reference this file.
```python
def _load_raw() -> dict[str, Any]:
    ref = importlib.resources.files("splinter.models") / "ladder.yaml"
    with importlib.resources.as_file(ref) as p:
        with open(p) as f:
            data: dict[str, Any] = yaml.safe_load(f)
```