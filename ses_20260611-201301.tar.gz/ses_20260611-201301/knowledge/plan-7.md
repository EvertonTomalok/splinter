# Plan

Enough. Plan scoped to ACs (setup verify only — not full provider/dispatch wiring, ACs don't require it).

## Implementation Plan — US-007: `splinter setup` verifies codex CLI

1. **`splinter/providers/codex.py` (new)** — minimal subprocess wrapper, mirror `claude_cli.ping`/`opencode.list_models` idiom. Header `from __future__ import annotations`. Add:
   - `def ping(timeout: int = 30) -> tuple[bool, str]:` — invoke codex non-interactively (`codex exec "respond with only the word ok"`, or `codex --help` fallback if exec unavailable — confirm exact subcommand before coding). Use `subprocess.run([...], capture_output=True, text=True, timeout=timeout)`. Return `(True, "")` when returncode 0 AND stdout non-empty/contains expected token; else `(False, <reason>)`. **No `--version` call, no version-string parsing** (NO version pin per AC). Wrap `FileNotFoundError`/`subprocess.TimeoutExpired` → `(False, <msg>)`. Full type hints, no comments.

2. **`splinter/setup.py` — add `_check_codex()`** — parallel to `_check_claude` (setup.py:25). Body:
   - `path = shutil.which("codex")`; if falsy → `return False, "codex not found in PATH"` (clear missing error).
   - `ok, detail = codex.ping()`; if not ok → `return False, detail or "codex did not return valid output"` (clear invalid error).
   - else `return True, path`.
   - Add `codex` to the import: `from splinter.providers import claude_cli, codex, opencode` (line 9).

3. **`splinter/setup.py` — wire into `run_setup()`** — after opencode check (~setup.py:93) add:
   ```python
   ok, _ = _check("codex CLI", _check_codex)
   results.append(ok)
   ```
   `all(results)` gate already returns exit 1 on any FALHA — drives `cli.py:30 setup()` exit code. No change to `cli.py`.

4. **`tests/test_core.py` — add tests** (use `monkeypatch`, no real CLI):
   - `test_check_codex_valid`: monkeypatch `shutil.which` → fake path, `codex.ping` → `(True, "")`; assert `_check_codex()[0] is True`.
   - `test_check_codex_missing`: `shutil.which` → `None`; assert `(False, "codex not found in PATH")`.
   - `test_check_codex_invalid`: `which` → path, `ping` → `(False, "...")`; assert `[0] is False`.
   - Optional: `codex.ping` unit — monkeypatch `subprocess.run` returning fake `CompletedProcess` (rc 0 + valid stdout → True; rc 1 / empty → False; raise `FileNotFoundError` → False).
   - Import `from splinter.setup import _check_codex` and `from splinter.providers import codex`. Don't touch existing tests.

5. **Gate** — run `uv run mypy --strict splinter/`, `uv run ruff check splinter/ tests/`, `uv run pytest tests/test_core.py -k codex`. All pass; fix any untyped-def / line-length(100) / isort issues.

**Confirm before coding:** exact codex non-interactive subcommand+flags (`codex exec`? `codex run`?) — determines step 1 invocation. Want me to verify codex CLI surface, or proceed assuming `codex exec`?
