# Plan

Read enough. Findings drive plan:

- `ModelProvider.run()` interface lacks `output_format` + `agent` — dispatch passes both. `localizer.py:287` passes `output_format="text"` (claude text path differs from json). Must preserve → extend interface.
- `run_text`'s `session` param = Session log object, NOT resume id. Keep separate (don't pass to backend).
- claude session-id fallback: old returns `_session_id or session`; `ProviderResponse.session_id` = `_session_id or None`. Must re-add `or session` in dispatch.
- No codex anywhere: `provider_for` only maps opencode/claude; no `codex.py`; registry has 2 providers. Codex acceptance needs those enablers (US-001/002/003 deps) — included as conditional steps.

## Implementation Plan — US-004 dispatch delegation

**1. Extend provider interface — `splinter/providers/base.py`**
Add two kwargs to abstract `ModelProvider.run()` so dispatch passes uniform params (absorbs the backend param-name differences instead of branching):
```python
@abstractmethod
def run(
    self,
    prompt: str,
    model: str,
    *,
    variant: str | None = None,
    output_format: str = "json",
    session: str | None = None,
    timeout: int | None = None,
    agent: str = "build",
) -> ProviderResponse: ...
```

**2. `ClaudeProvider.run` — `splinter/providers/claude_cli.py:236`**
Accept `output_format` + `agent` (claude ignores `agent`). Forward `output_format` to `claude_cli.run` (preserves localizer `"text"` path — currently lost if dropped):
```python
result = run(prompt, model, effort=variant, output_format=output_format, resume=session, timeout=timeout)
```
Response build unchanged.

**3. `OpencodeProvider.run` — `splinter/providers/opencode.py:279`**
Accept `output_format`; map to `fmt=output_format` in the inner `run(...)` call. `agent` already present. Response build unchanged.

**4. Rewrite `splinter/providers/dispatch.py`**
- Imports: drop `claude_cli`, `opencode`; add `from dataclasses import replace`, `from splinter.providers.registry import get_provider`. Keep `provider_for`, `ProviderResponse`.
- `run_text` (line 16): resolve once, delegate. `session` stays log-only (do NOT pass as resume):
```python
resp = get_provider(provider_for(model)).run(
    prompt, model, variant=variant, output_format=output_format, timeout=timeout, agent=agent
)
if session is not None:
    _log(session, model, resp.tokens, resp.cost)
return resp.text
```
- `_log` (line 43): unchanged. Remove the `claude_cli._calc_cost` dependency (now `resp.cost`).
- `run_text_session` (line 50): delegate with `session=session`; `sid = resp.session_id or session` (re-adds claude's `or session` fallback); `return resp.text, sid`.
- `run_provider_session` (line 86): delegate; `sid = (resp.session_id or session) or None`; `return replace(resp, session_id=sid), sid`.

**5. Codex routing enablers (acceptance: codex never falls through to claude)** — only if US-001/002/003 haven't landed them:
- `splinter/models/roster.py:11` `provider_for`: add codex id prefix branch → return `"codex"` before the claude default.
- `splinter/providers/codex.py`: create `CodexProvider(ModelProvider)` (`name = "codex"`) implementing the step-1 signature, parallel to `claude_cli.py`.
- `splinter/providers/registry.py:13`: add `CodexProvider()` to the `_PROVIDERS` tuple.

**6. Tests — `tests/test_core.py`**
- `monkeypatch` `get_provider` (or `_PROVIDERS`) with a recording fake; assert `run_text`/`run_text_session`/`run_provider_session` call the provider resolved by `provider_for` — claude id→claude, opencode id→opencode, codex id→codex.
- Assert codex id never invokes `ClaudeProvider` (no fall-through).
- Behavior-preservation: assert session-id fallback returns the passed-in `session` when provider yields `None`; assert `_log` fired only when `session` object present in `run_text`.
- Do not edit existing passing tests (`test_evaluator.py`, `test_eval_skill.py`, `test_cowabunga_prd.py` patch dispatch symbols — verify their patch targets still resolve).

**7. Gate**
`mypy --strict` + ruff (E,F,W,I, line 100). Run full unit suite — no regression in the 4 consumers (`runner.py`, `evaluator.py`, `gate.py:259`, `localizer.py`).

Want me to implement, or adjust scope (e.g. drop step 5 if codex provider lands in a prior US)?
