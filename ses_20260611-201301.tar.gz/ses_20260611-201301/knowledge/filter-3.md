### splinter/providers/registry.py:L1-L14 — Provider registration mechanism
rtk: rtk read splinter/providers/registry.py
Registry dict comprehension must include CodexProvider instance; import path needed.
```python
from splinter.providers.base import ModelProvider
from splinter.providers.claude_cli import ClaudeProvider
from splinter.providers.opencode import OpencodeProvider

_PROVIDERS: dict[str, ModelProvider] = {p.name: p for p in (ClaudeProvider(), OpencodeProvider())}
```

### splinter/providers/registry.py:L17-L24 — get_provider lookup function
rtk: rtk read splinter/providers/registry.py
get_provider("codex") will resolve to _PROVIDERS["codex"] if CodexProvider.name is "codex".
```python
def get_provider(name: str) -> ModelProvider:
    """Return the provider strategy registered under ``name``."""
    try:
        return _PROVIDERS[name]
    except KeyError:
        raise ValueError(
            f"unknown provider '{name}'. Available: {', '.join(sorted(_PROVIDERS))}"
        ) from None
```

### splinter/providers/base.py:L19-L31 — ModelProvider ABC interface
rtk: rtk read splinter/providers/base.py
CodexProvider must inherit from ModelProvider, define `name: ClassVar[str]`, and implement `run()`.
```python
class ModelProvider(ABC):
    """A pluggable backend that can run a prompt against a named model."""

    name: ClassVar[str]

    @abstractmethod
    def run(
        self,
        prompt: str,
        model: str,
        *,
        variant: str | None = None,
        session: str | None = None,
        timeout: int | None = None,
    ) -> ProviderResponse:
        """Execute ``prompt`` against ``model`` and return a normalised response."""
        ...
```

**Action**: Import `CodexProvider` into registry.py and add to the tuple in `_PROVIDERS` dict comprehension.