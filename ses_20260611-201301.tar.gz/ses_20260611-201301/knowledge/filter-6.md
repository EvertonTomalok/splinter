### splinter/providers/registry.py:L9-L17 — Provider registration
rtk: rtk read splinter/providers/registry.py
Where new providers (including codex) must be registered and made discoverable to the rest of the system.
```python
_PROVIDERS: dict[str, ModelProvider] = {p.name: p for p in (ClaudeProvider(), OpencodeProvider())}


def get_provider(name: str) -> ModelProvider:
    """Return the provider strategy registered under ``name``."""
    try:
        return _PROVIDERS[name]
    except KeyError:
        raise ValueError(
            f"unknown provider '{name}'. Available: {', '.join(sorted(_PROVIDERS))}"
        ) from None
```

### splinter/models/roster.py:L7-L11 — Model-to-provider routing
rtk: rtk read splinter/models/roster.py
Logic that determines which provider backend handles a model id; must be extended to recognize codex model ids.
```python
def provider_for(model_id: str) -> str:
    """Infer the provider from a model id."""
    if model_id.startswith("opencode-go/") or model_id.startswith("opencode/"):
        return "opencode"
    return "claude"
```

### splinter/models/roster.py:L27-L45 — Ladder tier configuration
rtk: rtk read splinter/models/roster.py
Tier dataclass defines which models and providers are available; codex models must be added to tiers with provider="codex".
```python
@dataclass
class Tier:
    name: str
    level: int
    models: list[str]
    provider: str = "opencode"
    variants: dict[str, str | None] = field(default_factory=dict)
```

### splinter/agents/runner.py:L76-L80 — Model resolution for runs
rtk: rtk read splinter/agents/runner.py
Maps tier level to model id and provider; codex models will be resolved here once registered in ladder.
```python
def resolve_model(tier_level: int, ladder: Ladder) -> tuple[str, str]:
    """Map a ladder tier level to its primary model id and provider name."""
    tier = ladder.tier_by_level(tier_level)
    return tier.models[0], tier.provider
```

### splinter/cli.py:L60-L79 — CLI model override options
rtk: rtk read splinter/cli.py
TUI entry point for PRD; passes `run_kwargs` to `run_prd_interactive` which would handle model selection (codex models should appear in that TUI).
```python
    run_kwargs = {
        "description": description,
        "strategy": strategy,
        "prd_path": None,
        "task_path": None,
        "effort": None,
        "budget": None,
        "max_iterations": 5,
        "cowabunga": False,
        "no_ground": no_ground,
    }
    raise typer.Exit(run_prd_interactive(run_kwargs))
```

### splinter/configure.py:L14-L22 — Final eval config schema
rtk: rtk read splinter/configure.py
`FinalEvalEntry` has `model` field; if final eval gates support codex models, schema already exists but TUI must expose codex in dropdown.
```python
@dataclass(frozen=True)
class FinalEvalEntry:
    """A single final eval gate in the ordered list."""

    name: str
    kind: FinalEvalKind
    skill: str | None = None
    cmd: str | None = None
    model: str | None = None
    variant: Variant | None = None
```