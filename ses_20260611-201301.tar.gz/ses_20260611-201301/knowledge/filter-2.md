### splinter/models/roster.py:L1-L11 — provider_for function
rtk: rtk read splinter/models/roster.py
Current `provider_for` only infers from model_id prefix, ignoring explicit tier provider labels. Needs enhancement to check explicit provider configuration from loaded ladder.
```python
def provider_for(model_id: str) -> str:
    """Infer the provider from a model id."""
    if model_id.startswith("opencode-go/") or model_id.startswith("opencode/"):
        return "opencode"
    return "claude"
```

### splinter/models/roster.py:L61-L107 — load_ladder function
rtk: rtk read splinter/models/roster.py | sed -n '61,107p'
Parses tier configuration with explicit `provider` field. Must populate a mapping so `provider_for` can resolve by explicit label, not just prefix.
```python
def load_ladder(raw: dict[str, Any] | None = None) -> Ladder:
    if raw is None:
        raw = _load_raw()

    tiers: list[Tier] = []
    for td in raw["tiers"]:
        tiers.append(
            Tier(
                name=td["name"],
                level=td["level"],
                models=td["models"],
                provider=td.get("provider", "opencode"),
                variants=td.get("variants", {}),
            )
        )
```

### splinter/providers/dispatch.py:L19-L35 — run_text dispatch
rtk: rtk read splinter/providers/dispatch.py
Calls `provider_for(model)` without ladder context to route ad-hoc calls. Mislabeling risk: if tier has `provider: "claude"` but `provider_for` infers "opencode" from prefix, sends to wrong backend.
```python
def run_text(
    prompt: str,
    model: str,
    *,
    ...
) -> str:
    """Run ``prompt`` on ``model``'s backend and return the response text."""
    if provider_for(model) == "opencode":
        oc = opencode.run(...)
        ...
        return oc.text
    cl = claude_cli.run(...)
```

### splinter/models/roster.py:L25-L35 — Tier dataclass
rtk: rtk read splinter/models/roster.py | sed -n '25,35p'
Tier stores explicit provider label (default "opencode"). This field must drive resolution in `provider_for` to prevent mislabeling when tier config contradicts model_id prefix.
```python
@dataclass
class Tier:
    name: str
    level: int
    models: list[str]
    provider: str = "opencode"
    variants: dict[str, str | None] = field(default_factory=dict)
```