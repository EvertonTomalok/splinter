# Localization — Task 3

### splinter/providers/codex.py — reason: New provider implementation for codex CLI integration — parallel to claude_cli.py and opencode.py
file: splinter/providers/codex.py
symbol: reason: New provider implementation for codex CLI integration — parallel to claude_cli.py and opencode.py
rtk: rtk read splinter/providers/codex.py
reason: New provider implementation for codex CLI integration — parallel to claude_cli.py and opencode.py

### splinter/providers/registry.py — get_provider
file: splinter/providers/registry.py
symbol: get_provider
rtk: rtk read splinter/providers/registry.py
reason: Provider registry — must register codex provider alongside claude, opencode

### splinter/providers/dispatch.py — run_text
file: splinter/providers/dispatch.py
symbol: run_text
rtk: rtk read splinter/providers/dispatch.py
reason: Provider dispatch — routes model calls to providers; must handle codex model IDs

### splinter/providers/dispatch.py — run_provider_session
file: splinter/providers/dispatch.py
symbol: run_provider_session
rtk: rtk read splinter/providers/dispatch.py
reason: Session dispatch — routes to appropriate provider for codex models

### splinter/providers/base.py — reason: Base provider interface — codex provider must implement this contract
file: splinter/providers/base.py
symbol: reason: Base provider interface — codex provider must implement this contract
rtk: rtk read splinter/providers/base.py
reason: Base provider interface — codex provider must implement this contract

### README.md:L91-L139 — line_start: 91
file: README.md
symbol: line_start: 91
line_start: 91
line_end: 139
rtk: rtk read README.md | sed -n '91,139p'
reason: Documentation on authentication and setup — currently shows claude and opencode; must add codex setup (lines 128-139 region, and codex CLI install like line 91)

### README.md:L262-L289 — line_start: 262
file: README.md
symbol: line_start: 262
line_start: 262
line_end: 289
rtk: rtk read README.md | sed -n '262,289p'
reason: Models list — must document codex models in the provider roster section

### models/ladder.yaml — reason: Model tier definitions and roster — must add codex models to the ladder (referenced in AGENTS.md:62)
file: models/ladder.yaml
symbol: reason: Model tier definitions and roster — must add codex models to the ladder (referenced in AGENTS.md:62)
rtk: rtk read models/ladder.yaml
reason: Model tier definitions and roster — must add codex models to the ladder (referenced in AGENTS.md:62)

### splinter/models/roster.py — reason: Ladder dataclass and loader — must define codex model structs and add to roster
file: splinter/models/roster.py
symbol: reason: Ladder dataclass and loader — must define codex model structs and add to roster
rtk: rtk read splinter/models/roster.py
reason: Ladder dataclass and loader — must define codex model structs and add to roster

### splinter/configure.py:L345-L345 — line_start: 345
file: splinter/configure.py
symbol: line_start: 345
line_start: 345
line_end: 345
rtk: rtk read splinter/configure.py | sed -n '345,345p'
reason: Configuration and TUI — must support codex model selection alongside opencode and claude (line 345 imports opencode)

### splinter/agents/runner.py:L13-L13 — get_provider
file: splinter/agents/runner.py
symbol: get_provider
line_start: 13
line_end: 13
rtk: rtk read splinter/agents/runner.py | sed -n '13,13p'
reason: Task runner — uses provider registry to dispatch models; must route codex models correctly (line 13)

### splinter/agents/evaluator.py:L17-L17 — run_provider_session
file: splinter/agents/evaluator.py
symbol: run_provider_session
line_start: 17
line_end: 17
rtk: rtk read splinter/agents/evaluator.py | sed -n '17,17p'
reason: Evaluator agent — dispatches to providers; must handle codex model routing (line 17)

### splinter/agents/gate.py:L259-L259 — run_text
file: splinter/agents/gate.py
symbol: run_text
line_start: 259
line_end: 259
rtk: rtk read splinter/agents/gate.py | sed -n '259,259p'
reason: Gate agent — runs mechanical checks via provider dispatch; must support codex (line 259)

### splinter/agents/localizer.py:L16-L16 — run_text
file: splinter/agents/localizer.py
symbol: run_text
line_start: 16
line_end: 16
rtk: rtk read splinter/agents/localizer.py | sed -n '16,16p'
reason: Localizer — finds relevant code; uses provider dispatch; must route to codex (line 16)

### splinter/cli.py:L30-L30 — verify
file: splinter/cli.py
symbol: verify
line_start: 30
line_end: 30
rtk: rtk read splinter/cli.py | sed -n '30,30p'
reason: Environment verification — checks available providers; must detect and validate codex CLI installation (line 30)

### pyproject.toml — reason: Project dependencies — may need codex CLI detection or optional dependency configuration
file: pyproject.toml
symbol: reason: Project dependencies — may need codex CLI detection or optional dependency configuration
rtk: rtk read pyproject.toml
reason: Project dependencies — may need codex CLI detection or optional dependency configuration

### tests/test_core.py — reason: Core tests — must add tests for codex provider dispatch, model routing, and CLI integration
file: tests/test_core.py
symbol: reason: Core tests — must add tests for codex provider dispatch, model routing, and CLI integration
rtk: rtk read tests/test_core.py
reason: Core tests — must add tests for codex provider dispatch, model routing, and CLI integration

### AGENTS.md:L62-L71 — line_start: 62
file: AGENTS.md
symbol: line_start: 62
line_start: 62
line_end: 71
rtk: rtk read AGENTS.md | sed -n '62,71p'
reason: Development guide — documents provider architecture (line 71: providers/ directory); should note codex as supported provider alongside claude and opencode
