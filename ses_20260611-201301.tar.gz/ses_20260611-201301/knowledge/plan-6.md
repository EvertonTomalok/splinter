# Plan

No `codex.py` yet. Task US-006 scoped to configure TUI: surface codex ids in `available_models()` + make them selectable (route-recognizable). Full provider/dispatch wiring is other US — out of scope here. Plan keeps to AC + gate.

## Implementation Plan — US-006

1. **Define codex model ids (source of truth).** Add `models/ladder.yaml` anchors under `models:` for codex (e.g. `codex_gpt5: &codex_gpt5 codex/gpt-5.1`, `codex_mini: &codex_mini codex/gpt-5.1-mini`). Use `codex/` prefix to mirror `opencode/` namespacing. No new tier required for selection — anchors alone won't surface them, so see step 3.

2. **Recognize codex prefix in routing.** Edit `splinter/models/roster.py` `provider_for(model_id)` (L11-15): add `if model_id.startswith("codex/"): return "codex"` before the `opencode` check. Keeps return type `str`, mypy-clean. Makes any selected codex id route to a `codex` provider name (registry registration is a later US; selection itself is now meaningful).

3. **Surface codex in `available_models()`.** Edit `splinter/configure.py` `available_models()` (L339-355). Add a static codex id set mirroring the opencode block — no live CLI call (no codex provider listing exists). Define module constant `CODEX_MODELS: list[str] = ["codex/gpt-5.1", "codex/gpt-5.1-mini"]` near `EFFORT_CHOICES`, then `models.update(CODEX_MODELS)` before the `return sorted(models)`. Update docstring to mention codex. Result: sorted list includes claude + opencode + ladder + codex.

4. **Tests.** In `tests/test_core.py` add:
   - `test_available_models_includes_codex` — assert every `CODEX_MODELS` id present in `available_models()`.
   - `test_provider_for_codex` — `provider_for("codex/gpt-5.1") == "codex"`; regression-assert opencode/claude unchanged.

5. **Docs.** `README.md` models roster section (L262-289): add codex row. `AGENTS.md` L62-71: note codex as a provider namespace alongside claude/opencode. Optional, no gate impact.

6. **Gate.** Run `mypy --strict splinter` + `ruff check splinter tests` (line-length 100, isort). All new code typed, `from __future__ import annotations` already present in both files. Fix any findings; gate must pass.

**Scope note:** registry registration (`registry.py`), `codex.py` provider impl, and dispatch wiring are NOT in US-006 (TUI selection only). Codex ids become selectable + route-tagged; actual execution lands in the provider-impl US. Flag if you want that pulled in here.
