### splinter/cli.py:L13-L17 — setup() command entry point
rtk: rtk read splinter/cli.py
Entry point for `splinter setup` command; calls `run_setup()` which needs implementation to verify CLIs.
```python
@app.command()
def setup() -> None:
    """Verify environment and providers."""
    from splinter.setup import run_setup

    raise typer.Exit(run_setup())
```

### splinter/providers/registry.py:L1-L24 — provider registry and lookup
rtk: rtk read splinter/providers/registry.py
Shows available providers (Claude, opencode) that setup must verify are callable; `available_providers()` lists them by name.
```python
"""Lookup of :class:`ModelProvider` strategies by name.

The runner resolves a provider name (from the active ladder tier) into a concrete
strategy here, so the call site never branches on the backend.
"""

from __future__ import annotations

from splinter.providers.base import ModelProvider
from splinter.providers.claude_cli import ClaudeProvider
from splinter.providers.opencode import OpencodeProvider

_PROVIDERS: dict[str, ModelProvider] = {p.name: p for p in (ClaudeProvider(), OpencodeProvider())}


def get_provider(name: str) -> ModelProvider:
    """Return the provider strategy registered under ``name``."""
    try:
        return _PROVIDERS[name]
    except KeyError:
        raise ValueError(
            f"unknown provider '{name}'. Available: {', '.join(sorted(_PROVIDERS))}"
        ) from None


def available_providers() -> list[str]:
    """Names of all registered providers."""
    return sorted(_PROVIDERS)
```

### README.md:L27-L43 — environment requirements
rtk: rtk read README.md
Lists required CLIs (claude, opencode) and Python 3.11+ that setup must verify are installed and functional.
```markdown
## Requirements

Splinter is the conductor, not the models. You bring the two CLIs it drives:

- **[uv](https://github.com/astral-sh/uv)** the Python project manager Splinter
  is built on
- **Python 3.11+** (uv can install it for you)
- **[Claude Code](https://docs.claude.com/en/docs/claude-code/overview)** the
  `claude` CLI, authenticated, with access to `sonnet` and `opus-4.8`
- **[opencode](https://opencode.ai)** the `opencode` CLI, authenticated on the
  `opencode-go` provider _(not needed if you use `--use-cc-only`, see below)_
```