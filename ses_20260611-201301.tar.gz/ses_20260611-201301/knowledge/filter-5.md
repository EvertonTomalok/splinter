### splinter/models/roster.py:L1-L20 — provider_for() routing logic
rtk: rtk read splinter/models/roster.py
Determines which backend handles a model id — needs to route codex models to correct provider
```python
def provider_for(model_id: str) -> str:
    """Infer the provider from a model id."""
    if model_id.startswith("opencode-go/") or model_id.startswith("opencode/"):
        return "opencode"
    return "claude"
```

### splinter/models/roster.py:L23-L32 — Tier dataclass
rtk: rtk read splinter/models/roster.py
Tier struct holding models list and provider name — where ladder.yaml tiers populate into
```python
@dataclass
class Tier:
    name: str
    level: int
    models: list[str]
    provider: str = "opencode"
    variants: dict[str, str | None] = field(default_factory=dict)
```

### splinter/models/roster.py:L36-L70 — Ladder dataclass
rtk: rtk read splinter/models/roster.py
Main ladder config struct with tiers list and model references — central place models live
```python
@dataclass
class Ladder:
    tiers: list[Tier]
    effort_map: dict[str, EffortMapping]
    eval_model: str
    eval_effort: str
    planner_model: str
    planner_effort: str
    localizer_recall_model: str
    localizer_recall_large_model: str
    localizer_precision_model: str
    localizer_recall_variant: str = "minimal"
    localizer_recall_large_variant: str = "minimal"
    localizer_precision_variant: str = "low"
    localizer_recall_fallback_model: str = "haiku"
    localizer_agent: str = "explore"
    localizer_relevance_hot: float = 0.8
    localizer_relevance_medium: float = 0.4
    # per-tier reasoning variant override, keyed by tier level (else effort_map)
    tier_variants: dict[int, str] = field(default_factory=dict)
    # per-step subprocess timeout (seconds); default filled from config in load_ladder
    default_timeout: int = 3600
    eval_timeout: int = 3600
    planner_timeout: int = 3600
    localizer_recall_timeout: int = 3600
    localizer_recall_large_timeout: int = 3600
    localizer_precision_timeout: int = 3600
    tier_timeouts: dict[int, int] = field(default_factory=dict)
```

### splinter/models/roster.py:L105-L140 — load_ladder() YAML parser
rtk: rtk read splinter/models/roster.py
Parses ladder.yaml into Ladder struct — shows how tier/model fields map from YAML
```python
def load_ladder(raw: dict[str, Any] | None = None) -> Ladder:
    if raw is None:
        raw = _load_raw()

    tiers: list[Tier] = []
    for td in raw["tiers"]:
        tiers.append(
            Tier(
                name=td["name"],
                level=td["level"],
                models=td["models"],
                provider=td.get("provider", "opencode"),
                variants=td.get("variants", {}),
            )
        )

    effort_map: dict[str, EffortMapping] = {}
    for name, em in raw.get("effort_map", {}).items():
        effort_map[name] = EffortMapping(start_tier=em["start_tier"], variant=em["variant"])
```

### splinter/providers/registry.py:L1-L24 — provider registration
rtk: rtk read splinter/providers/registry.py
Shows how providers register themselves — codex models will need a provider entry or route to existing one
```python
_PROVIDERS: dict[str, ModelProvider] = {p.name: p for p in (ClaudeProvider(), OpencodeProvider())}


def get_provider(name: str) -> ModelProvider:
    """Return the provider strategy registered under ``name``."""
    try:
        return _PROVIDERS[name]
    except KeyError:
        raise ValueError(
            f"unknown provider '{name}'. Available: {', '.join(sorted(_PROVIDERS))}"
        ) from None
```

### splinter/providers/dispatch.py:L1-L15 — dispatch routing comment
rtk: rtk read splinter/providers/dispatch.py
Documents current routing: opencode-go/* → opencode, claude aliases → claude CLI — shows dispatch precedent for codex
```python
"""Route a single model call to the backend that owns the model id.

The rule is simple and absolute: ``opencode-go/*`` ids go to the ``opencode`` CLI,
claude aliases (``opus``/``sonnet``/``haiku``) go to ``claude -p``. Sending an
opencode model to the claude CLI 404s (and vice versa), so every ad-hoc model
call (localize, plan, eval) funnels through here instead of hardcoding a provider.
"""
```