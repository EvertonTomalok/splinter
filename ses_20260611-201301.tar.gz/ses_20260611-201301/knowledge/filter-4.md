### splinter/providers/registry.py:L1-16 — Provider registry and resolution
```python
"""Lookup of :class:`ModelProvider` strategies by name.

The runner resolves a provider name (from the active ladder tier) into a concrete
strategy here, so the call site never branches on the backend.
"""

from __future__ import annotations

from splinter.providers.base import ModelProvider
from splinter.providers.claude_cli import ClaudeProvider
from splinter.providers.opencode import OpencodeProvider

_PROVIDERS: dict[str, ModelProvider] = {p.name: p for p in (ClaudeProvider(), OpencodeProvider())}


def get_provider(name: str) -> ModelProvider:
    """Return the provider strategy registered under ``name``."""
    try:
        return _PROVIDERS[name]
    except KeyError:
        raise ValueError(
            f"unknown provider '{name}'. Available: {', '.join(sorted(_PROVIDERS))}"
        ) from None
```
**rtk: rtk read splinter/providers/registry.py**
This is the correct pattern — get_provider() resolves by name and returns a provider object. dispatch.py should use this instead of if/else branching.

---

### splinter/providers/base.py:L16-42 — ModelProvider interface and ProviderResponse
```python
@dataclass(frozen=True)
class ProviderResponse:
    """Backend-agnostic result of a single model invocation."""

    text: str
    tokens: dict[str, int] = field(default_factory=dict)
    cost: float = 0.0
    raw: dict[str, Any] = field(default_factory=dict)
    session_id: str | None = None


class ModelProvider(ABC):
    """A pluggable backend that can run a prompt against a named model."""

    name: ClassVar[str]

    @abstractmethod
    def run(
        self,
        prompt: str,
        model: str,
        *,
        variant: str | None = None,
        session: str | None = None,
        timeout: int | None = None,
    ) -> ProviderResponse:
        """Execute ``prompt`` against ``model`` and return a normalised response."""
        ...
```
**rtk: rtk read splinter/providers/base.py**
All providers (ClaudeProvider, OpencodeProvider) implement this interface. dispatch.py should call provider.run() and work with ProviderResponse, which normalizes both backends into one contract.

---

### splinter/agents/runner.py:L43-55 — Correct delegation pattern (reference implementation)
```python
def resolve_model(tier_level: int, ladder: Ladder) -> tuple[str, str]:
    """Map a ladder tier level to its primary model id and provider name."""
    tier = ladder.tier_by_level(tier_level)
    return tier.models[0], tier.provider
```
**rtk: rtk read splinter/agents/runner.py | sed -n '43,85p'**
runner.py already shows the correct pattern: get provider name → use get_provider() → call provider.run(). See full run_task() for complete example (lines ~75-90 in the visible snippet, where provider.run() is called).

---

### splinter/providers/dispatch.py:L11-59 — Current if/else antipattern (run_text)
```python
def run_text(
    prompt: str,
    model: str,
    *,
    variant: str | None = None,
    output_format: str = "json",
    timeout: int | None = None,
    agent: str = "build",
    session: object = None,
) -> str:
    """Run ``prompt`` on ``model``'s backend and return the response text."""
    if provider_for(model) == "opencode":
        oc = opencode.run(
            prompt, model, variant=variant, fmt=output_format, timeout=timeout, agent=agent
        )
        if session is not None:
            _log(session, model, oc.tokens, oc.cost)
        return oc.text
    cl = claude_cli.run(prompt, model, effort=variant, output_format=output_format, timeout=timeout)
    if session is not None:
        _log(session, model, {
            "input": cl.usage.get("input_tokens", 0) or 0,
            "output": cl.usage.get("output_tokens", 0) or 0,
        }, claude_cli._calc_cost(model, cl.usage))
    return cl.text
```
**rtk: rtk read splinter/providers/dispatch.py**
Current pattern: hardcoded if/else branching on provider name, direct calls to opencode.run() and claude_cli.run(). Needs refactor to: resolve provider object → call provider.run() → extract response fields consistently.

---

### splinter/providers/dispatch.py:L61-95 — If/else antipattern (run_text_session)
```python
def run_text_session(
    prompt: str,
    model: str,
    *,
    variant: str | None = None,
    output_format: str = "json",
    session: str | None = None,
    timeout: int | None = None,
    agent: str = "build",
) -> tuple[str, str | None]:
    """Like :func:`run_text`, but resumes ``session`` and returns the (text, new
    session id). Used by the evaluator to keep one conversation across retries of
    the same runner — pass the returned id back in to continue it."""
    if provider_for(model) == "opencode":
        oc = opencode.run(
            prompt,
            model,
            variant=variant,
            fmt=output_format,
            session=session,
            timeout=timeout,
            agent=agent,
        )
        sid = session or oc.raw.get("session_id") or oc.raw.get("session")
        return oc.text, sid
    cl = claude_cli.run(
        prompt,
        model,
        effort=variant,
        output_format=output_format,
        resume=session,
        timeout=timeout,
    )
    return cl.text, (cl.raw.get("_session_id") or session)
```
**rtk: rtk read splinter/providers/dispatch.py**
Same antipattern: branching logic plus parameter name/field mapping differences between backends (variant vs effort, fmt vs output_format, etc). After refactor, provider.run() returns ProviderResponse with normalized fields.

---

### splinter/providers/dispatch.py:L97-135 — If/else antipattern (run_provider_session)
```python
def run_provider_session(
    prompt: str,
    model: str,
    *,
    variant: str | None = None,
    output_format: str = "json",
    session: str | None = None,
    timeout: int | None = None,
    agent: str = "build",
) -> tuple[ProviderResponse, str | None]:
    """Like :func:`run_text_session` but returns the full :class:`ProviderResponse`
    (with cost and token counts) alongside the session id."""
    if provider_for(model) == "opencode":
        oc = opencode.run(...)
        sid = session or oc.raw.get("session_id") or oc.raw.get("session")
        resp = ProviderResponse(
            text=oc.text,
            tokens=oc.tokens,
            cost=oc.cost,
            raw=oc.raw,
            session_id=sid,
        )
        return resp, sid
    cl = claude_cli.run(...)
    sid = cl.raw.get("_session_id") or session
    resp = ProviderResponse(...)
    return resp, sid
```
**rtk: rtk read splinter/providers/dispatch.py**
Same pattern repeats — if/else with manual ProviderResponse construction. If both backends returned ProviderResponse directly, these conversions would be unnecessary.

---

### splinter/models/roster.py:L<line> — provider_for() function (locator of model→provider mapping)
**rtk: rtk grep "def provider_for" splinter/**
provider_for(model: str) returns the provider name (e.g., "opencode" or "claude"). dispatch.py uses this to decide which branch to take — should remain as input to get_provider() instead.

---

## Summary for Implementation

**Task refactor path:**
1. Import `get_provider` from `splinter.providers.registry` in dispatch.py
2. In each function: `provider = get_provider(provider_for(model))`
3. Call `provider.run()` with normalized params (variant, output_format, session, timeout)
4. Extract fields from the returned `ProviderResponse` object (text, tokens, cost, raw, session_id)
5. Remove the if/else and direct imports of `opencode` / `claude_cli` modules from dispatch.py

The registry pattern (runner.py) is the reference — delegation replaces branching.