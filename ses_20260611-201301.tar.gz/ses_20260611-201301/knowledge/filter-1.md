### splinter/providers/base.py:L1-L48 — ModelProvider ABC & ProviderResponse contract
rtk: rtk read splinter/providers/base.py
Defines the abstract interface that `CodexProvider` must implement and the normalized response type.
```python
"""Strategy interface for model providers.

Each provider (claude CLI, opencode CLI) is a concrete :class:`ModelProvider`
that knows how to invoke its backend and normalise the response into a
:class:`ProviderResponse`. The runner selects one by name via the registry in
:mod:`splinter.providers.registry`, so adding a backend means adding a strategy —
no ``if provider == ...`` branching at the call site.
"""

from __future__ import annotations

import re
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, ClassVar


@dataclass(frozen=True)
class ProviderResponse:
    """Backend-agnostic result of a single model invocation."""

    text: str
    tokens: dict[str, int] = field(default_factory=dict)
    cost: float = 0.0
    raw: dict[str, Any] = field(default_factory=dict)
    session_id: str | None = None


class ModelProvider(ABC):
    """A pluggable backend that can run a prompt against a named model."""

    name: ClassVar[str]

    @abstractmethod
    def run(
        self,
        prompt: str,
        model: str,
        *,
        variant: str | None = None,
        session: str | None = None,
        timeout: int | None = None,
    ) -> ProviderResponse:
        """Execute ``prompt`` against ``model`` and return a normalised response."""
        ...
```

---

### splinter/providers/registry.py:L1-L27 — Provider registration mechanism
rtk: rtk read splinter/providers/registry.py
Shows where to register the new `CodexProvider`. Add it to `_PROVIDERS` dict.
```python
"""Lookup of :class:`ModelProvider` strategies by name.

The runner resolves a provider name (from the active ladder tier) into a concrete
strategy here, so the call site never branches on the backend.
"""

from __future__ import annotations

from splinter.providers.base import ModelProvider
from splinter.providers.claude_cli import ClaudeProvider
from splinter.providers.opencode import OpencodeProvider

_PROVIDERS: dict[str, ModelProvider] = {p.name: p for p in (ClaudeProvider(), OpencodeProvider())}


def get_provider(name: str) -> ModelProvider:
    """Return the provider strategy registered under ``name``."""
    try:
        return _PROVIDERS[name]
    except KeyError:
        raise ValueError(
            f"unknown provider '{name}'. Available: {', '.join(sorted(_PROVIDERS))}"
        ) from None


def available_providers() -> list[str]:
    """Names of all registered providers."""
    return sorted(_PROVIDERS)
```

---

### splinter/models/roster.py:L6-L10 — Model-to-provider router
rtk: rtk read splinter/models/roster.py | sed -n '1,15p'
Routes model IDs to providers. Must extend to recognize codex model IDs (e.g., `codex/*`).
```python
def provider_for(model_id: str) -> str:
    """Infer the provider from a model id."""
    if model_id.startswith("opencode-go/") or model_id.startswith("opencode/"):
        return "opencode"
    return "claude"
```

---

### splinter/providers/dispatch.py:L8-L35 — Provider dispatch pattern
rtk: rtk read splinter/providers/dispatch.py | sed -n '1,50p'
Shows how providers are invoked via `provider_for()` routing. Codex models will need similar branching logic here.
```python
def run_text(
    prompt: str,
    model: str,
    *,
    variant: str | None = None,
    output_format: str = "json",
    timeout: int | None = None,
    agent: str = "build",
    session: object = None,
) -> str:
    """Run ``prompt`` on ``model``'s backend and return the response text."""
    if provider_for(model) == "opencode":
        oc = opencode.run(
            prompt, model, variant=variant, fmt=output_format, timeout=timeout, agent=agent
        )
        if session is not None:
            _log(session, model, oc.tokens, oc.cost)
        return oc.text
    cl = claude_cli.run(prompt, model, effort=variant, output_format=output_format, timeout=timeout)
    if session is not None:
        _log(session, model, {
            "input": cl.usage.get("input_tokens", 0) or 0,
            "output": cl.usage.get("output_tokens", 0) or 0,
        }, claude_cli._calc_cost(model, cl.usage))
    return cl.text
```

---

### splinter/agents/runner.py:L48-L70 — Provider resolution & run invocation
rtk: rtk read splinter/agents/runner.py | sed -n '48,85p'
Shows how `get_provider()` is called from the runner. Your provider will be instantiated here.
```python
def resolve_variant(
    task: Task,
    effort_override: str | None,
    ladder: Ladder,
    tier_level: int | None = None,
) -> str:
    """Pick the reasoning variant.

    Precedence: CLI override > task setting > per-tier config > ladder effort map.
    """
    if effort_override and effort_override != Variant.AUTO:
        return effort_override
    if task.reasoning_effort and task.reasoning_effort != Variant.AUTO:
        return task.reasoning_effort
    if tier_level is not None:
        configured = ladder.tier_variant(tier_level)
        if configured:
            return configured
    em = ladder.effort_mapping(task.effort)
    if em:
        return em.variant
    # Agentic floor — never low/minimal for code generation.
    return Variant.MEDIUM


def resolve_model(tier_level: int, ladder: Ladder) -> tuple[str, str]:
    """Map a ladder tier level to its primary model id and provider name."""
    tier = ladder.tier_by_level(tier_level)
    return tier.models[0], tier.provider
```