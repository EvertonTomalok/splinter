# Localization

file: splinter/providers/codex.py
symbol: 
reason: New provider implementation for codex CLI integration — parallel to claude_cli.py and opencode.py
confidence: 0.95
relevance: hot

file: splinter/providers/registry.py
symbol: get_provider
reason: Provider registry — must register codex provider alongside claude, opencode
confidence: 0.95
relevance: hot

file: splinter/providers/dispatch.py
symbol: run_text
reason: Provider dispatch — routes model calls to providers; must handle codex model IDs
confidence: 0.9
relevance: hot

file: splinter/providers/dispatch.py
symbol: run_provider_session
reason: Session dispatch — routes to appropriate provider for codex models
confidence: 0.9
relevance: hot

file: splinter/providers/base.py
symbol: 
reason: Base provider interface — codex provider must implement this contract
confidence: 0.95
relevance: hot

file: README.md
symbol: 
line_start: 91
line_end: 139
reason: Documentation on authentication and setup — currently shows claude and opencode; must add codex setup (lines 128-139 region, and codex CLI install like line 91)
confidence: 0.95
relevance: hot

file: README.md
symbol: 
line_start: 262
line_end: 289
reason: Models list — must document codex models in the provider roster section
confidence: 0.9
relevance: hot

file: models/ladder.yaml
symbol: 
reason: Model tier definitions and roster — must add codex models to the ladder (referenced in AGENTS.md:62)
confidence: 0.9
relevance: hot

file: splinter/models/roster.py
symbol: 
reason: Ladder dataclass and loader — must define codex model structs and add to roster
confidence: 0.9
relevance: hot

file: splinter/configure.py
symbol: 
line_start: 345
line_end: 345
reason: Configuration and TUI — must support codex model selection alongside opencode and claude (line 345 imports opencode)
confidence: 0.85
relevance: hot

file: splinter/agents/runner.py
symbol: get_provider
line_start: 13
line_end: 13
reason: Task runner — uses provider registry to dispatch models; must route codex models correctly (line 13)
confidence: 0.85
relevance: hot

file: splinter/agents/evaluator.py
symbol: run_provider_session
line_start: 17
line_end: 17
reason: Evaluator agent — dispatches to providers; must handle codex model routing (line 17)
confidence: 0.85
relevance: hot

file: splinter/agents/gate.py
symbol: run_text
line_start: 259
line_end: 259
reason: Gate agent — runs mechanical checks via provider dispatch; must support codex (line 259)
confidence: 0.85
relevance: hot

file: splinter/agents/localizer.py
symbol: run_text
line_start: 16
line_end: 16
reason: Localizer — finds relevant code; uses provider dispatch; must route to codex (line 16)
confidence: 0.85
relevance: hot

file: splinter/cli.py
symbol: verify
line_start: 30
line_end: 30
reason: Environment verification — checks available providers; must detect and validate codex CLI installation (line 30)
confidence: 0.85
relevance: hot

file: pyproject.toml
symbol: 
reason: Project dependencies — may need codex CLI detection or optional dependency configuration
confidence: 0.6
relevance: medium

file: tests/test_core.py
symbol: 
reason: Core tests — must add tests for codex provider dispatch, model routing, and CLI integration
confidence: 0.7
relevance: medium

file: AGENTS.md
symbol: 
line_start: 62
line_end: 71
reason: Development guide — documents provider architecture (line 71: providers/ directory); should note codex as supported provider alongside claude and opencode
confidence: 0.7
relevance: medium

file: skills/prd/SKILL.md
symbol: 
reason: skill definition: prd
confidence: 0.95
relevance: hot

file: skills/run_python/SKILL.md
symbol: 
reason: skill definition: run_python
confidence: 0.95
relevance: hot

