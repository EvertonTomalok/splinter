---
feature: codex-provider
strategy: cascade
kind: feature
created: 2026-06-11
---

## 1. Introduction/Overview
Add `codex` as a first-class model provider alongside `claude` and `opencode`. Today `splinter/providers/dispatch.py` branches two-way (`if opencode / else claude`) in every dispatch function — a fragile pattern that silently routes unknown provider ids to the claude CLI. This feature adds the codex adapter AND replaces the if/else dispatch with a strategy-pattern router so providers own their dispatch behavior via the `base.py` contract.

## 2. Goals
- `codex/*` model ids route to a real codex CLI adapter end-to-end.
- Dispatch no longer branches on provider name; it resolves a provider object and delegates (strategy pattern).
- Codex tiers carry an explicit `provider: codex` label; no silent mislabel.
- `splinter setup` validates codex CLI presence + valid return.
- Models/config docs cover codex.

## 3. User Stories

### US-001: Codex provider adapter
**Description:** As Splinter, I want a `CodexProvider` in `providers/codex.py` implementing the `base.py` contract so codex model calls execute against the codex CLI.

**Splinter hints:**
- effort: hard
- eval_skill: run_python

**Acceptance Criteria:**
- [x] `providers/codex.py` defines `CodexProvider(BaseProvider)` (parallel to `opencode.py`/`claude_cli.py`).
- [x] Implements `run_text` and `run_provider_session` per `base.py`.
- [x] Custom flags/output parsing confirmed against installed codex CLI (NOT assumed to match claude/opencode I/O).
- [x] Canonical codex model ids confirmed against installed CLI and recorded for US-005.
- [x] Typecheck/lint passes (gate).

**Tests:**
- [x] {{ discover unit tests for CodexProvider adapter — mock subprocess I/O }} — all must pass. Do not force any previous test to pass.

### US-002: `provider_for` recognizes `codex/*`
**Description:** As Splinter, I want `provider_for` to resolve codex by both explicit label AND model-id prefix so tiers are never mislabeled.

**Splinter hints:**
- effort: trivial

**Acceptance Criteria:**
- [x] Codex tiers in ladder require explicit `provider: codex` (no `opencode` default fallback for codex).
- [x] `provider_for` also infers `codex` from `codex/*` model-id prefix as safety net.
- [x] Typecheck/lint passes (gate).

**Tests:**
- [x] {{ unit test: explicit label + prefix inference both resolve codex }} — all must pass. Do not force any previous test to pass.

### US-003: Registry registration
**Description:** As Splinter, I want `CodexProvider` registered in `providers/registry.py` so `get_provider("codex")` returns it.

**Splinter hints:**
- effort: trivial

**Acceptance Criteria:**
- [x] `registry.py` registers codex alongside claude/opencode.
- [x] `get_provider("codex")` returns `CodexProvider`.
- [x] Typecheck/lint passes (gate).

**Tests:**
- [x] {{ unit test: registry returns CodexProvider for "codex" }} — all must pass. Do not force any previous test to pass.

### US-004: Strategy-pattern dispatch router (central regression)
**Description:** As Splinter, I want `dispatch.py` to resolve a provider object and delegate, replacing the two-way if/else in all dispatch functions.

**Splinter hints:**
- effort: hard
- eval_skill: run_python

**Acceptance Criteria:**
- [ ] `run_text`, `run_provider_session` (and any third dispatch fn) delegate to the provider object from registry — no `if opencode / else claude` branching.
- [ ] All 4 consumers verified unchanged in behavior for claude/opencode: `runner.py:13`, `evaluator.py:17`, `gate.py:259`, `localizer.py:16`.
- [ ] Codex ids dispatch to `CodexProvider`, never fall through to claude CLI.
- [ ] Typecheck/lint passes (gate).

**Tests:**
- [ ] {{ unit tests: dispatch routes claude/opencode/codex to correct provider; no regression }} — all must pass. Do not force any previous test to pass.

### US-005: Ladder + roster codex entries
**Description:** As Splinter, I want codex models in `models/ladder.yaml` and `models/roster.py` structs.

**Splinter hints:**
- effort: normal

**Acceptance Criteria:**
- [ ] `roster.py` defines codex model structs.
- [ ] `ladder.yaml` adds codex tiers with explicit `provider: codex` and canonical ids confirmed in US-001.
- [ ] Typecheck/lint passes (gate).

**Tests:**
- [ ] {{ unit test: roster loads codex tiers }} — all must pass. Do not force any previous test to pass.

### US-006: Configure TUI `available_models`
**Description:** As a user, I want codex models selectable in the configure TUI.

**Splinter hints:**
- effort: normal

**Acceptance Criteria:**
- [ ] `configure.py` (see L345 opencode import) lists codex in `available_models`.
- [ ] Codex models selectable alongside claude/opencode.
- [ ] Typecheck/lint passes (gate).

### US-007: `splinter setup` codex CLI check
**Description:** As a user, I want `splinter setup` to verify codex CLI is present and returns valid output.

**Splinter hints:**
- effort: normal

**Acceptance Criteria:**
- [ ] `cli.py:30 verify` detects codex CLI on PATH.
- [ ] Invokes codex CLI and confirms return is valid (NO version pin).
- [ ] Clear error if missing or returns invalid.
- [ ] Typecheck/lint passes (gate).

**Tests:**
- [ ] {{ unit test: verify passes on valid return, fails on missing/invalid }} — all must pass. Do not force any previous test to pass.

### US-008: README docs
**Description:** As a user, I want codex setup + models documented in README.

**Splinter hints:**
- effort: trivial

**Acceptance Criteria:**
- [ ] README plumbing/setup region (L128-139) documents codex CLI install.
- [ ] Models roster section (L262-289) lists codex models.
- [ ] Setup prose L91-92/L135-139 partly staged (+9 diff); fill the missing plumbing + models section.

## 4. Functional Requirements
- FR-1: `CodexProvider` must implement `base.py` `run_text` and `run_provider_session`.
- FR-2: Dispatch must resolve provider via registry object and delegate — no name branching.
- FR-3: `provider_for` must resolve codex by explicit `provider: codex` AND `codex/*` prefix.
- FR-4: `get_provider("codex")` must return `CodexProvider`.
- FR-5: `splinter setup` must fail with clear message on missing codex CLI or invalid return (presence + valid-return, no version pin).
- FR-6: Codex model ids must be confirmed against installed CLI before ladder entry.

## 5. Non-Goals (Out of Scope)
- No removal/change of claude or opencode behavior.
- No new TUI features beyond listing codex in `available_models`.
- No auth/login flow for codex (US-007 is presence + valid-return only).
- No codex CLI version pinning.

## 6. Design Considerations
- Configure TUI: reuse existing `available_models` rendering; add codex entries only.

## 7. Technical Considerations
**Impact / regression list (anchored):**
- `dispatch.py:run_text`, `dispatch.py:run_provider_session` (+third fn) — REWRITE to strategy router. Central regression surface.
- Consumers that must not break: `runner.py:13 get_provider`, `evaluator.py:17 run_provider_session`, `gate.py:259 run_text`, `localizer.py:16 run_text`. Each exercises dispatch — verify claude/opencode unchanged.
- `provider_for` default `td.get("provider","opencode")` — must NOT apply to codex tiers (would mislabel). Explicit label + prefix inference (US-002).
- `codex.py` absent — net-new, model after `base.py` contract; I/O shape unconfirmed (custom flags/parsing, US-001).
- Strategy `cascade`: stories chain (US-001 confirms ids/CLI contract → US-002/003/005 depend on it; US-004 router is the central regression gate). Sequential escalation fits the dependency order.

## 8. Success Metrics
- No lint error.
- No build error.
- No unit test errors (US-001..005, US-007).

## 9. Open Questions
- Exact codex CLI flags + stdout/JSON output format — confirm against installed CLI in US-001 (deferred-by-design).
- Canonical codex model ids — confirm in US-001, fill ladder in US-005 (deferred-by-design).
