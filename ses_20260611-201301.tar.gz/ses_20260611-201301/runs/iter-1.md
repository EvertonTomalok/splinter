# Run output — iteration 1
- model: sonnet (tier 3)
- tokens: {'input': 22, 'output': 12584}
- cost: $0.1888

All pass (excluding the pre-existing failure in `test_evaluator.py`). Summary of changes:

**`splinter/providers/base.py`** — added `output_format: str = "json"` and `agent: str = "build"` to abstract `ModelProvider.run()` signature.

**`splinter/providers/claude_cli.py`** — `ClaudeProvider.run()` accepts + forwards `output_format` to inner `run()`; `agent` accepted but ignored (claude CLI has no agent concept).

**`splinter/providers/opencode.py`** — `OpencodeProvider.run()` accepts `output_format`, forwards as `fmt=` to inner `run()`.

**`splinter/providers/codex.py`** — `CodexProvider.run()` accepts `output_format` and `agent`; both silently ignored (codex CLI has no equivalents).

**`splinter/providers/dispatch.py`** — fully rewritten: no `claude_cli`/`opencode`/`codex` imports, no if/else branching. All 3 functions resolve `get_provider(provider_for(model))` and delegate to `provider.run(...)`. Session-id fallback `resp.session_id or session` re-added for `run_text_session` and `run_provider_session`; `dataclasses.replace` keeps `resp.session_id == sid` invariant.

**`tests/test_core.py`** — added 8 dispatch routing tests covering: claude/opencode routing, session logging, session-id fallback, `resp.session_id == sid` invariant, and an AST-based assertion that dispatch.py imports no provider modules directly.

**`tests/test_cowabunga_prd.py`** — updated `test_run_text_routes_by_model_id` to patch `dispatch.get_provider` instead of the removed `dispatch.claude_cli`/`dispatch.opencode` attributes.
